# Project instructions

These instructions apply to work in this repository and its subdirectories.

## Fresh rebuild decisions — 2026-10-25

- The user selected a completely fresh implementation. Preserve documents, fonts and design assets; do not copy legacy implementation code or assume migration of existing users, data or database schemas. Do not delete or reset the existing project. Decision D07 fixes the fresh project destination at `/Users/mohsentouiserkani/Projects/didban-mali-rebuild`, a separate sibling folder. Recording the destination does not establish that it has been created or implemented.
- Read `docs/rebuild-spec.fa.md` for the current product decisions and `design.md` for current design intent. The old MVP specification and exception-first build plan are historical references wherever they conflict with those decisions.
- Decision D01: first-release financial inputs support only rial and toman. Foreign-currency accounts/invoices, FX rates and revaluation are out of scope. Preserve the original unit, convert toman to canonical IRR exactly, and never treat foreign or unknown units as IRR. Follow `docs/rebuild-decision-review.fa.md` for remaining decisions; ask them one at a time.
- Decision D02: a missing source family alone does not block the whole session. Produce independently valid results and mark dependent metrics unavailable with null, a specific missing-source reason and a completion action. A finished session with incomplete reporting scope is completed_limited; valid individual metrics can remain available. Necessary ambiguity questions still pause the entire session. Supplemental inputs create a new revision/report without mutating previous snapshots.
- Decision D03: initial account-role classification may be accepted automatically with evidence and valid independent controls; do not require blanket first-use human approval. Model confidence alone is insufficient. Persist automatic provenance, evidence, control results and policy/effective versions. Ambiguity triggers the existing session-wide question barrier. Preserve valid human decisions; coverage and tax completeness remain separate checks.
- Decision D04: advisors/accountants may submit financial clarification answers, accept reconciliation proposals, and create/reverse payment-to-invoice allocations within their authorized companies. Enforce authorization, versions, capacity and audit history on the server. This grants neither bank money movement nor report-approval or administrative permissions.
- Decision D05: a company's finance manager may approve that company's report. Owners and advisors/accountants require an explicit company-scoped approve_financial_report permission; viewers cannot approve. Check current membership/permission at approval time and record actor, time, permission provenance and exact report version. Automatic generation/download is independent of approval; approval never transfers to a revised report.
- Decision D06: archive a source while financial/report dependencies remain; preserve its original file and evidence. Archiving must not silently remove financial effects or alter historical reports. Hard deletion requires explicit authorization and resolved dependencies, including historical manifests, reports and decisions. Neither cascading deletion nor retention may bypass this guard; reversing an allocation alone does not erase historical dependencies.
- Decision D08: only a current owner of the same company may grant/revoke the explicit report-approval permission for owners/advisors/accountants. Log actor, recipient, company, time and before/after permission values. Finance-manager approval authority does not grant permission-administration authority. Ownership alone must not automatically grant approval; even a self-grant is an explicit audited action. Enforce current permission on new approvals without erasing historical approvals.
- Read `docs/rebuild-financial-contract.fa.md` and `docs/rebuild-technical-contract.fa.md` before implementing the fresh domain or workflow. They record version 0.1 rules, proposed engineering defaults and remaining validation gates separately; do not treat unvalidated thresholds or a proposed permission matrix as explicit user approval.
- The user selected separate ledger and invoice bases for receivables/payables. Keep both visible and never add them together. Compute their difference only for comparable commercial scopes, counterparties, dates and coverage; loans, tax and payroll liabilities are not missing purchase invoices.
- The first release includes every agreed business area, including receivables, payables, cashflow, Moadian and settlements. Intermediate vertical slices are development milestones, not permission to reduce the first-release scope.
- Only Excel/CSV inputs are in scope; target up to 10 files and approximately 20,000 total data rows per upload session. PDF output is required; PDF/image/ZIP input and OCR are deferred. Support arbitrary source families through validated interpretation; do not promise untested universal correctness.
- A necessary clarification opens a focused shared Dialog and blocks the entire processing session on the server until a valid answer arrives. Closing the Dialog or browser preserves the question and pause. Do not continue independent branches as the old plan proposed. Existing committed effects remain auditable; resume without duplicate effects.
- Each organization has a private installation with multiple isolated companies and owner, finance manager, advisor/accountant and viewer roles. Accounts are created/invited by the organization administrator; no public signup. The assistant is read-only. Notifications are in-product only.
- The user explicitly finalized the revised `didban-luminous` design and its font sizes/weights on 2026-10-25. `design.md` and the preserved snapshot `docs/design-reference/didban-luminous.html` are the approved visual baseline for the new project. The sample-review prerequisite is satisfied; do not request approval again to implement this baseline. Legacy palettes and screenshots do not override it.
- Legacy component paths below describe shared responsibilities and quality requirements. Recreate the shared components and tokens in the new implementation rather than importing legacy code. Keep controls, tables, charts and feedback centralized.
- Ask remaining product questions one at a time. Do not ask again about recorded choices. Distinguish explicit user decisions from engineering proposals and from unverified implementation status.

## Approved rebuild design and typography

- Match the approved light, lively, luxurious and smooth design, composition, restrained gradients, opaque surfaces, spacing and interaction language. Do not independently redesign the product, enlarge headings again, or restore the legacy maritime palette.
- Signature `#5556DE`, primary hover `#4345BF`, soft accent `#EEEDFF`, canvas `#F6F7FC`, surface `#FFFFFF`, main text `#20243F`, secondary text `#68718A`, border `#E9ECF5`. Status colors and the full contract are in `design.md`. The optional jade preview was not selected as the baseline. Implement colors as shared semantic tokens consumed through Tailwind.
- Page titles: Anjoman Max Medium, 26px/500. Dialog and empty-state titles: 20px/500. Large section, case and report titles: 18px/500. Product name: 16px/500. Ordinary section/chart headings: IRANYekanX Medium, 14px/500. Do not use Bold/ExtraBold as the default interface heading weight.
- Body text: IRANYekanX Regular, 14px/400. Standard actions: IRANYekanX Medium, 14px/500; compact actions 12px/500. Financial metric numbers: IRANYekanX Medium, 28px/500; the approved main cash display uses Anjoman Max Medium, 48px/500, and the cash-view display 36px/500. Keep readable units and tabular numbers.
- Register the real `AnjomanMax-Medium.woff2` at 500, `IRANYekanX-Regular.ttf` at 400 and `IRANYekanX-Medium.ttf` at 500. Do not label a Bold font as Medium, synthesize font weights, or substitute fonts. The PDF font-weight requirements remain separate.
- Preserve the approved geometry: main summary/dialog radius 24px, ordinary panel radius 20px, button/navigation selection radius 12px; content padding 20px on mobile and 28px on larger layouts. Keep shared controls and accessibility requirements below.
- Use the approved motion baseline: control feedback 200ms; page reveal 280ms with 5px vertical movement and `cubic-bezier(.2,.7,.2,1)`; dialog entrance 240ms with 7px vertical movement. Use shared motion tokens, reduced-motion fallbacks, and actual processing state. Complete metric loading/value-change feedback consistently; do not copy demo delays or fabricated progress.
- Preserve the snapshot as a design asset when creating the fresh project; its interactive fragment needs a preview host. Do not copy its mock data, demo workflow or prototype primitives into production. Reimplement shared components and real state cleanly against the approved design.
- Visual approval is explicit; it does not prove financial correctness, backend integration, full-page coverage or successful runtime/reduced-motion tests. Verify the new implementation in the built-in Codex Browser as required below.

## UI and UX design requirements

- Preserve the approved font system: IRANYekanX for body text and numeric data, Anjoman Max for headings and the explicitly approved cash display figures. Use shared font tokens; do not introduce or substitute fonts without an explicit user request.
- For the fresh rebuild, follow the approved `design.md` theme and tokens rather than legacy product tokens. In the new implementation, reuse its shared color, typography, spacing, border, radius and component tokens consistently across all pages.
- All user-facing form controls must use the project's shared components in `apps/web/components/ui`, including text and numeric inputs, textareas, selects, checkboxes, radio groups, switches, and date pickers. This applies to forms, filters, tables, dialogs, and drawers throughout the application.
- Browser-default controls are not acceptable in product UI. In particular, never use a raw HTML `<select>` or a native browser dropdown as a substitute for the project's `Select` component. Use `Input`, `Textarea`, `Checkbox`, `RadioGroup`, `Switch`, and `PersianDatePicker` for their respective controls. Styling a native control directly in a page does not satisfy this requirement.
- All action buttons, including icon-only actions and overlay close buttons, must use the shared `Button`. Compose modals from the shared `Dialog`, side overlays from `Drawer`/`Sheet`, and destructive confirmations from `ConfirmDialog` in `apps/web/components/ui`. Do not build page-local modal backdrops, portals, focus traps, or raw dialog elements; keep overlay behavior and styling in the shared components. Preserve deliberately non-modal workspace panels as non-modal.
- If a required control is missing, create or extend a reusable shared component consistent with the existing design system before using it in a page. Native elements needed internally by shared components for semantics, accessibility, or file selection must not expose an unstyled browser-default control to users.
- Before any UI design, redesign, or frontend layout change, read and apply the relevant available design skills. Start with `.agents/skills/ui-ux-design/SKILL.md` and use other applicable design skills when needed. Skill use is mandatory for design work.
- Give distinct business entities their own navigation and dedicated management pages. Do not put every feature and management form into a single page.
- Financial periods must be a first-class entity with dedicated create, read, update, and delete (CRUD) flows. Reporting pages may select a period; period management belongs in its own area.
- Use icons consistently with the project's existing icon library and components. Use purposeful animations for transitions, interaction feedback, and state changes; respect reduced-motion preferences.
- Maintain clear visual hierarchy, readable tables, appropriate spacing, accessible controls, and usable responsive layouts. Preserve Persian RTL behavior throughout.
- Check the affected pages after every design change, including dependent pages, populated and empty states, loading and error states, and mobile layouts. Fix visual and interaction regressions before considering the work complete.
- The receivables page has been reported as visually disrupted after the recent changes. Treat this as an existing issue to address when working on that page; do not assume the current layout is an acceptable design reference.

## Interaction and information architecture

- Design filters around a clear user task. Give controls explicit labels, group related choices, make the active selection and affected results apparent, and provide a clear way to reset. Avoid presenting saved periods, date presets, custom ranges, and management actions as an undifferentiated row of competing controls.
- Filters must have purposeful feedback for selection, expansion/collapse, and resulting data updates. Use short, consistent transitions; do not rely on color changes alone to explain state.
- Page navigation and asynchronous loading must provide visible, consistent feedback. Use skeletons that match the eventual layout, a restrained loading animation, and a smooth reveal of loaded content. Preserve layout and avoid flashes, artificial delays, or replaying entrance animations on every render.
- Statistics cards must have their own restrained motion for initial appearance, loading-to-data transitions, and actual value changes. A hover color transition alone does not satisfy this requirement. Keep values readable and accurate, avoid layout shifts and replaying animations on unrelated renders, and honor reduced-motion preferences with static feedback.
- Animate transitions between views that remain within one workspace, including any retained tabs. Respect reduced-motion preferences with immediate state changes and static loading feedback. Animation does not make an unsuitable navigation structure acceptable.
- Do not use tabs to combine the current cashflow page's period report and 30-day forecast. They serve distinct tasks and need clear, separately addressable destinations within cashflow navigation, each with an obvious title and active navigation state.
- Design the daily balance and cash movement section around a decision the user needs to make. Do not reproduce the current chart followed by a long daily list as the default layout. Show an understandable summary and overview first, then offer relevant transaction or day details through deliberate drill-down. Add a full table only when it supports an identified task; keep its scope, filtering, and pagination clear.
- Keep data maintenance workflows separate from report consumption when their complexity warrants it. Receipt-history management is a candidate for its own page; the user has suggested this, but has not yet chosen that structure. Evaluate a dedicated page versus a focused contextual flow before implementing the move. Do not treat this suggestion as an approved relocation.
- Verify motion and interaction in the running browser, including filter changes, loading, page navigation, view changes, keyboard use, and reduced motion. Static screenshots and passing component tests alone do not establish that these requirements are met.
- Use the built-in Codex Browser for all project UI testing. Do not launch a separate browser or external browser window for these checks.

## Code quality and architecture

- All new and modified frontend and backend code must be clean, readable, maintainable, and consistent with applicable language, framework, security, and accessibility standards. Follow repository conventions unless they conflict with these instructions.
- Keep responsibilities separate, dependencies explicit, and functions and modules focused. Avoid duplication, unnecessary abstractions, oversized files, and unrelated changes.
- Extract distinct UI sections into focused components. Do not leave substantial independent sections embedded in a large page or view.
- When a component is used in multiple places, give it a name that reflects its shared responsibility rather than its original page. Update its file name, exports, imports, and usages consistently, and place it in the appropriate shared location.
- All views must be UI-only: render data and expose interaction callbacks. Keep fetching, mutations, business rules, calculations, data transformation, and workflow orchestration in dedicated hooks, services, or controllers outside the view. Local state for purely visual interactions may remain in the view.
- In the backend, keep routes/controllers focused on request validation, authentication/authorization, calling application services, and formatting responses. Put business rules in services/domain modules and database access in the appropriate data layer. Preserve transaction boundaries and company/tenant isolation.
- Use TypeScript types and Python type annotations appropriately. Validate external inputs, handle errors explicitly, and never expose secrets or sensitive data in logs or client responses.
- Use Tailwind CSS utilities for all new or changed UI styling. Use existing design tokens through Tailwind utilities; do not add handwritten CSS, CSS modules, inline style declarations, or CSS-in-JS for layout, typography, colors, spacing, or other visual styling.
- Animation definitions are the only exception to the Tailwind-only styling rule: custom keyframes and animation-specific CSS are allowed when needed. Keep all other styling in Tailwind.
- When modifying existing components, migrate the styling of the changed sections to Tailwind. Do not expand this into an unrelated project-wide migration unless requested.
- Verify changed behavior with appropriate checks and meaningful tests. Review shared component usages and affected views when extracting, renaming, or moving code.

## Product copy

- Keep visible text concise and necessary for the user's immediate task.
- Do not add unsolicited guidance, explanatory paragraphs, subtitles, subdescriptions, or repetitive helper text.
- Avoid verbose notices such as: «تاریخچه وصول ۱۰ فاکتور کامل نیست. برای محاسبه مانده تاریخی، تاریخ و مبلغ تمام وصول‌ها را ثبت کنید.»
- When a validation error or financial-data limitation must be shown to prevent misunderstanding, use the shortest clear message at the relevant control or result. Do not hide a material limitation or imply that incomplete calculations are complete.
- Concision must not make a message vague. Do not use unexplained labels such as «گزارش تاریخی ناقص است.» State the specific missing data and its effect on the affected result in language a financial user understands. Prefer a local unavailable state and a relevant action over a standalone warning paragraph; for example, identify missing receipt dates where they prevent calculating a period balance.
- Do not display «گردش بانک؛ شامل انتقال بین حساب‌ها» as a routine standalone sentence. Make the metric's scope clear through accurate labels and, only when needed, concise details available on demand. Retain material calculation limitations without filling the page with explanatory copy.

## UX implementation status

This section records legacy implementation history only. It does not establish implementation, testing or design acceptance for the fresh rebuild.

- The receivables page now places the specific missing-receipt-date limitation at the unavailable period balance. Current customer balances remain available. The period filter uses a compact summary and a focused selection drawer with explicit apply and reset actions.
- Shared overdue filters show a check mark and transition when selected. Page navigation has a skeleton and content reveal; statistics cards have staggered entrance and loading/value-update motion. Rendered animation styles and affected pages were checked in the running browser.
- The cashflow period report and 30-day forecast now have separate routes and sidebar destinations. The period report shows a balance overview; daily details open on demand in a drawer instead of a default long daily table. Desktop and mobile layouts and day navigation were checked.
- Receipt history remains a contextual drawer opened from the receivables header. A dedicated page remains a possible future design decision, not an approved relocation.
- Motion uses reduced-motion guards and static loading fallbacks. A live browser test with the operating system's reduced-motion preference enabled remains unverified; do not describe source checks as that test.
- Implementation and checks do not constitute user acceptance of the design. Continue applying the interaction requirements above to future changes.

## PDF generation preferences

- Use IRANYekanX as the default PDF font family.
- Embed/register IRANYekanX in every generated PDF when the font file is available.
- Prefer the regular, medium, bold, and extra-bold IRANYekanX weights when available.
- For Persian/Farsi text, use right-to-left layout and proper Arabic/Persian shaping.
- Default page size: A4.
- Default margins: 18mm to 22mm unless the document needs a denser layout.
- Use Persian digits only when the document language/context is Persian; otherwise keep standard Latin digits.
- If IRANYekanX is not available, ask before using a fallback font.
- Before finalizing important PDFs, render pages to images and visually check layout, text clipping, direction, and font rendering.

## Shared tables and statistical cards

- Compose every product table with `components/ui/table.tsx` (`Table`, header/body/row/cell primitives and `TableRowHeader` for row labels). Use `FinancialDataTable` for column-driven grids. Raw table elements belong only in the shared primitive implementation.
- Keep horizontal scrolling inside the shared table container; preserve keyboard access, RTL, header scope, loading/empty states, and existing mobile card alternatives.
- Use `components/ui/financial/stat-cards.tsx` for metric groups and `StatCard` or `KpiMetricCard` for individual metrics. Their common surface is `MetricCardFrame`; do not create independent KPI card shells in pages.
- Preserve zero versus unavailable data, exact financial values, loading/value-change motion, and reduced-motion behavior. Check affected tables and metrics in the built-in browser at desktop and mobile widths.

## Shared charts and content states

- Compose charts with `components/ui/financial/financial-chart.tsx`: `FinancialChart`, `ChartGrid`, `ChartXAxis`, `ChartYAxis`, `ChartTooltip` and `ChartTooltipSurface`. Keep chart-specific series and business data in focused views and hooks. Direct Recharts container/axis/tooltip infrastructure in product views is prohibited by ESLint.
- Use `LoadingState` for waiting regions and `Skeleton`/`Spinner` for their primitives. Match loading geometry to the eventual content, label the region in Persian, hide decorative skeletons from assistive technology, and respect reduced motion. Do not introduce custom loading rings or pulsing placeholders in pages.
- Use `EmptyState` (including the table's `TableEmptyCell`) for missing/filtered results, `ErrorState` for request and validation errors, and `StatusMessage` for contextual notices. Existing shared `Alert` remains appropriate for form feedback requiring its semantics/ref behavior. Reuse the common retry/reset actions; preserve local financial limitations.
- Distinguish missing chart values from zero, keep gaps disconnected, show a visible point for single-point data, and keep exact values available in details. Check rendered SVG dimensions, tooltips, keyboard use, and desktop/mobile states in the built-in browser; DOM node presence alone does not establish a visible chart.
- Next.js error boundaries should use the installed version's `retry` callback to re-fetch failed content. The global boundary must provide its own styles and fonts, and must not promise that an unverified financial operation succeeded.

## Shared menus, tabs, tooltips and status badges

- Compose action menus with `components/ui/dropdown-menu.tsx`. Use shared Popover for rich non-menu content. Preserve RTL arrow keys, Escape, selected/current states and focus return. Keep mobile menus within the viewport; prefer a direct list when nested menus cannot fit.
- Compose in-place tabs with `Tabs`, `TabsList`, `TabsTrigger`, and `TabsContent` from `components/ui/tabs.tsx`. Do not recreate tab roles on Button or native elements. Keep separately addressable business navigation as links, including cashflow report and forecast destinations.
- Use shared `Tooltip`/`ActionTooltip` for action descriptions and `Hint` for explanations that must also open by touch or keyboard. Use `TruncatedText` for clipped values so fully visible table cells do not add unnecessary focus stops. Do not use native HTML `title` tooltips. Tooltip descriptions must not hide required validation or material financial limitations.
- Use `Badge` as the common badge surface. Domain `StatusBadge`, `StatusChip`, and `RiskBadge` compose it; reuse them for statuses and keep domain labels accurate. Unknown statuses remain neutral and read «نامشخص». Preserve zero scores, readable labels, accessible decorative icons and reduced-motion guards.
- Verify desktop/mobile menus, actual tab keyboard interaction, tooltip dismissal, focus return and populated badges in the built-in browser. Component tests or source inspection do not replace browser verification.

## Shared notifications and form feedback

- Use `notify` and `Toaster` from `components/ui/sonner.tsx`; do not import Sonner directly in pages, hooks, or product components. Keep RTL, theme tokens, a Persian close label and usable mobile dismissal targets. Material error notifications remain until dismissed; inline validation must remain at the relevant control.
- Compose every form with `Form` from `components/ui/form.tsx` or `DrawerForm`, which uses it. Native constraints use concise Persian `FieldError` messages, preserve `aria-describedby`, mark invalid controls, and focus the first invalid field. Do not restore browser validation bubbles. Explicit custom validation may use `noValidate` and must provide equivalent field messages and focus handling.
- Use `FieldError` and `FieldDescription` from `components/ui/field.tsx` for field errors and helper text, and `FormMessage` for operation errors, success, or information inside a form. Keep `ErrorState` for failed content requests and `StatusMessage`/`Alert` for broader notices. Never display an empty error or announce historical errors as new failures.
- UI constraint checks are not domain validation: preserve financial rules and server validation in controllers/services. Do not submit invalid or whitespace-only required values. Keep values after a failed operation and do not auto-dismiss success before the user can read it.
- Test invalid submission, correction, field associations, first-error focus, dates, notification dismissal and desktop/mobile layouts in the built-in browser. Use non-sending previews or mocked services for success/error notifications when a real action would send a ticket, create business data, or confirm financial figures.
